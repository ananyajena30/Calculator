#include <gtk/gtk.h>


void
on_Delete_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_Dot_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_One_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Two_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Three_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Five_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Six_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Clear_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Four_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Seven_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Eight_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Nine_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Plus_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Zero_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Result_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_Multiply_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_Minus_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Divide_clicked                      (GtkButton       *button,
                                        gpointer         user_data);
